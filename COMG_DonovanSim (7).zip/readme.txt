Controls:

Mouse to look around
WASD to move
'E' to interact

Interactions:
When hit by rock monsters (thwomp), player will be reset to the start.